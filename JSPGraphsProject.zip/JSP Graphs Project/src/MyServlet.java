import java.io.IOException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import com.google.gson.Gson;

@WebServlet("/myservlet")
public class MyServlet extends HttpServlet {

	private static String removeLastChar(String str) {
	    return str.substring(0, str.length() - 1);
	}
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //MyClass myClass = new MyClass();
    	System.out.println("Received request");

        if (request.getParameter("search") != null) {
        	String searchText = request.getParameter("search");
        	//Call DB Here to get query results

        	
        	//request.setAttribute("myname",searchText);
        	// to read it in HTML <%String name = (String)request.getAttribute("myname"); out.println(name);%>
        	//request.getRequestDispatcher("searchresult.jsp").forward(request, response); 
        	//request.getRequestDispatcher("/searchresult.jsp").forward(request, response);
        	
            int x = 1;
            String countryName = "sa";
            int countryValue = 130;
            String countries = "[";
            while (x <= 4)
            {
                String oneCountry = "{\"name\":\""+countryName+"\",\"value\":\""+countryValue+"\"}";
                countries += oneCountry + ",";
                x++;
            }
            countries = removeLastChar(countries);
            countries = countries + "]";
        	System.out.println(countries);


        	x = 1;
            String subjectName = "��� �������";            
            String subjectEncoded = URLEncoder.encode(subjectName, "UTF-8");
            String subjects = "[";
            while (x <= 4)
            {
                String oneSubject = "{\"name\":\""+subjectEncoded+"\",\"value\":\""+x+"\"}";
                subjects += oneSubject + ",";
                x++;
            }
            subjects = removeLastChar(subjects);
            subjects = subjects + "]";
        	System.out.println(subjects);

        	
        	
        	String allData = "{\"countries\":" + countries ;
        	allData+= "," + "\"subjects\":" + subjects  ;
        	allData+= "}";
            response.getWriter().write(allData);

        	return;
        	
        	
        } else if (request.getParameter("byCountryName") != null) {
        	
        	String countryName = request.getParameter("byCountryName");
        	System.out.println(countryName);
        	
        	//Call DB here to get data for country give it's name
        	
            int x = 1;
            String deviceName = "Android";
            double deviceValue = 25;
            String devices = "[";
            while (x <= 4)
            {
                String oneDevice = "{\"name\":\""+deviceName+"\",\"value\":\""+deviceValue+"\"}";
                devices += oneDevice + ",";
                x++;
            }
            devices = removeLastChar(devices);
            devices = devices + "]";
        	System.out.println(devices);


        	x = 1;
            String opnionName = "Positive";            
            String opnionEncoded = URLEncoder.encode(opnionName, "UTF-8");
            double value = 25;
            String opnions = "[";
            while (x <= 4)
            {
                String opnionOne = "{\"name\":\""+opnionEncoded+"\",\"value\":\""+value+"\"}";
                opnions += opnionOne + ",";
                x++;
            }
            opnions = removeLastChar(opnions);
            opnions = opnions + "]";
        	System.out.println(opnions);

        	
        	
        	String allData = "{\"devices\":" + devices ;
        	allData+= "," + "\"opnions\":" + opnions  ;
        	allData+= "}";
            response.getWriter().write(allData);

        	return;
        	
        	
        }  else if (request.getParameter("leadingTags") != null) {
        	
        	String leadingTags = request.getParameter("leadingTags");
        	System.out.println(leadingTags);
        	
        	//Call DB here to get data for leadingTags 
        	
            int x = 1;
            String tagName = "���_����";
            String tagNameEncoded = URLEncoder.encode(tagName, "UTF-8");

            String tags = "[";
            while (x <= 10)
            {
                String oneTag = "{\"name\":\""+tagNameEncoded+"\"}";
                tags += oneTag + ",";
                x++;
            }
            tags = removeLastChar(tags);
            tags = tags + "]";
        	System.out.println(tags);

        	String allData = "{\"tags\":" + tags ;
        	allData+= "}";
            response.getWriter().write(allData);

        	return;
        	
        	
        } else {
            // ???
        	

        }
        response.getWriter().write("Error");

        //Redirect to page
        //request.getRequestDispatcher("/Home.jsp").forward(request, response);
    }

}